public class Adresa {

    String adresa;

    public Adresa(String adresa) {
        this.adresa = adresa;
    }

    public String toString() {
        return this.adresa;
    }

}
